#!/usr/bin/env python
# -*- coding: utf-8 -*-

from testsuite import main
main()
