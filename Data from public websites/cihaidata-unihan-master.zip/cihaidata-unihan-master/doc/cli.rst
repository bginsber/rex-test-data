.. _cli:

======================
Command Line Interface
======================

.. argparse::
    :module: scripts.process
    :func: get_parser
    :prog: cihaidata-unihan
