.. _index:

=====================
cihai dataset: unihan
=====================

.. include:: ../README.rst
    :start-line: 10

.. toctree::
    :maxdepth: 2

    api
    cli
    history
    roadmap
